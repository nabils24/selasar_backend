"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Schema_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Lucid/Schema"));
class default_1 extends Schema_1.default {
    constructor() {
        super(...arguments);
        this.tableName = 'dtl_bookings';
    }
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.string('kode_booking').notNullable();
            table
                .integer('booking_id')
                .unsigned()
                .references('id')
                .inTable('bookings')
                .onDelete('CASCADE');
            table.integer('paket_id').unsigned().references('id').inTable('pakets').onDelete('CASCADE');
            table.integer('jumlah_kamar').unsigned().notNullable();
            table.integer('harga').unsigned().notNullable();
            table.integer('total_harga').unsigned().notNullable();
            table.enum('status_dtl_booking', ['active', 'inactive']).notNullable();
            table.dateTime('created_at', { useTz: true });
            table.dateTime('updated_at', { useTz: true });
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
exports.default = default_1;
//# sourceMappingURL=1685769615605_dtl_bookings.js.map